package raid

import (
	"bufio"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"time"
)

func Request(method string, link string, token string, message string) {
	for {
		done, body := DoRequest(method, link, token)
		if done {
			fmt.Printf("Discord response:\n %s", body)
			fmt.Println(message)
			break
		}
		time.Sleep(1 * time.Second)
	}
}
func GetData(path string) []string {
	data, err := os.Open(path)
	if err != nil {
		fmt.Println("Make sure you've got the path:", path)
	}
	var lines []string
	scanner := bufio.NewScanner(data)
	for scanner.Scan() {
		lines = append(lines, scanner.Text())
	}
	defer data.Close()
	return lines
}

func DoRequest(method string, link string, token string) (done bool, body string) {
	// proxies := GetData("./proxies.txt")
	// randomIndex := rand.Intn(len(proxies))
	// pick := proxies[randomIndex]
	// if !strings.Contains(pick, "http") {
	// 	pick = "http://" + pick
	// }
	// url_i := url.URL{}
	// url_proxy, _ := url_i.Parse(pick)
	// transport := http.Transport{
	// 	Proxy: http.ProxyURL(url_proxy),
	// }
	// client := http.Client{
	// 	Transport: &transport,
	// }
	client := http.Client{}
	req, _ := http.NewRequest(method, link, nil)
	req.Header.Add("Authorization", token)
	res, err := client.Do(req)
	if err != nil {
		// fmt.Printf("Link: %s, Token: %s, Proxy: %s \n", link, token, pick)
		fmt.Println("Proxy is broken...Trying another one...")
		return false, ""
	}
	BodyF, _ := ioutil.ReadAll(res.Body)

	return true, string(BodyF)

}
