package raid

import (
	"fmt"

	"github.com/manifoldco/promptui"
)

func Options() {
	prompt := promptui.Select{
		Label: "Options",
		Items: []string{"Join", "Leave", "Raid", "Friend", "Dm", "Check tokens", "Scrape proxies"},
	}

	_, result, err := prompt.Run()

	if err != nil {
		fmt.Printf("There was an error %v\n", err)
		return
	}
	switch result {
	case "Join":
		Join()
	default:
		fmt.Println("Option doesn't exist yet.")
		Options()
	}
}
