package raid

import (
	"fmt"
	"strings"
)

var tokens = GetData("./tokens.txt")
var inviteCode string

// var proxies = GetData("./proxies.txt")

func Join() {
	fmt.Print("Invite code: ")
	fmt.Scanln(&inviteCode)
	inviteCode := strings.Replace(inviteCode, "https://discord.gg/", "", -1)
	invite := "https://discord.com/api/v8/invite/" + inviteCode
	for _, token := range tokens {
		fmt.Println(invite)
		Request("POST", invite, token, token+" joined.")
	}
}
