package servnuke

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"
)

type Resp struct {
	Message     string
	Retry_after float32
	Global      bool
}

var (
	resp  Resp
	mutex sync.Mutex
)

func DoReq(method string, url string, token string, datatype string, id string) int {
	mutex.Lock()
	client := &http.Client{}
	mutex.Unlock()
	req, _ := http.NewRequest(method, url, nil)
	req.Header.Add("Authorization", "Bot "+token)
	res, err := client.Do(req)
	if err != nil {
		fmt.Println("There was an error, make sure your connection to the internet works.")
	}
	body, _ := ioutil.ReadAll(res.Body)
	if len(string(body)) > 3 && strings.Contains(string(body), "retry_after") {
		mutex.Lock()
		json.Unmarshal(body, &resp)
		fmt.Println("Got ratelimited for", resp.Retry_after, "seconds.")
		time.Sleep(time.Duration(resp.Retry_after) * time.Second)
		mutex.Unlock()
		return 1
	}
	fmt.Println(datatype, id, "executed.")
	return 0
}

func Request(method string, url string, token string, wg *sync.WaitGroup, datatype string, id string) {
	for {
		res := DoReq(method, url, token, datatype, id)
		if res == 0 {
			wg.Done()
			break
		}
		time.Sleep(1 * time.Second)
	}
}

func GetData(path string) []string {
	data, err := os.Open(path)
	if err != nil {
		fmt.Println("Make sure you scrape the server first.") //[ ! ] Path not found.
	}
	var lines []string
	scanner := bufio.NewScanner(data)
	for scanner.Scan() {
		lines = append(lines, scanner.Text())
	}
	defer data.Close()
	return lines
}
