package servnuke

import (
	"bufio"
	"fmt"
	"io"
	"os/exec"

	"github.com/manifoldco/promptui"
)

var guild string
var token string

func Options() {
	if guild == "" && token == "" {
		fmt.Print("\n")
		fmt.Print("Token: ")
		fmt.Scan(&token)
		fmt.Print("Server ID: ")
		fmt.Scan(&guild)
		cmd := exec.Command("python", "pylib/scrape.py", token, guild)
		stdout, err := cmd.StdoutPipe()
		if err != nil {
			panic(err)
		}
		stderr, err := cmd.StderrPipe()
		if err != nil {
			panic(err)
		}
		err = cmd.Start()
		if err != nil {
			panic(err)
		}

		go copyOutput(stdout)
		go copyOutput(stderr)

		cmd.Wait()
	}
	prompt := promptui.Select{
		Label: "Options",
		Items: []string{"Ban all", "Delete channels", "Delete roles", "Delete emojis", "Destroy"},
	}

	_, result, err := prompt.Run()

	if err != nil {
		fmt.Printf("There was an error %v\n", err)
		return
	}

	switch result {
	case "Ban all":
		BanAll(guild, token)
	case "Delete channels":
		DelChannels(guild, token)
	case "Delete roles":
		DelRoles(guild, token)
	case "Delete emojis":
		DelEmojis(guild, token)
	case "Destroy":
		BanAll(guild, token)
		DelChannels(guild, token)
		DelRoles(guild, token)
		DelEmojis(guild, token)
	}
}

func copyOutput(r io.Reader) {
	scanner := bufio.NewScanner(r)
	for scanner.Scan() {
		fmt.Println(scanner.Text())
	}
}
