package main

func main() {
	menu() // Starts the menu
}
