<h1 style="text-align:center">Spora - Discord Multitool</h1>
</br>
<h2>Platforms</h2>
<ul>
  <li>Windows</li>
  <p> Doesn't work on your platform? Join our Discord server and ask for support.</p>
</ul>
</br>
<h2>How to use</h2>
<ol>
<li>Install Python and Go.</li>
<li>Install python dependencies.</li>
<pre>pip install discord</pre>
<li>Get go dependencies.</li>
<pre>go get</pre>
<li>Build the go file</li>
<pre>go build</pre>
<li>Run the exe from terminal.</li>
</ol>
<h3>Features:</h3>
<ul>
<li>Nuke options ✅</li>
<li>Spam/Raid options ❌</li>
<li>Selfbot options ❌</li>
<li>Token grabber builder ❌</li>
<li> Plugins system ❌</li>
</ul>
<p>New ideas soon...</p>
<br>
<p style="font-size: 200%;">Feel free to contribute!<p>
</br>
<!-- <p style="font-size: 170%;"> Bugs you may meet: </p>
<ul>
<li>Program doesn't ask for token.</li>
</ul> -->
<a href="https://discord.gg/6GERPuvThh">Join Discord Server</a>
</br>
<h2 style="text-align:center;">Disclaimer</h2>
<p>I am not responsible for anything you damage using Spora, it is made just for educational purposes only.</p>
