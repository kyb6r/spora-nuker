import discord, sys, os
from discord.ext import commands


try:
    os.mkdir('./scraped/')
except Exception as E:
    print(E)
    

f = open('.\scraped\members.txt', 'w')
f.close()

b = open('.\scraped\channels.txt', 'w')
b.close()

k = open(r'.\scraped\roles.txt', 'w')
k.close()

u = open(r'.\scraped\emojis.txt', 'w')
u.close()

TOKEN = sys.argv[1]
GUILD = int(sys.argv[2])

intents = discord.Intents.all()
client = commands.Bot(command_prefix='2439x', intents=intents)


@client.event
async def on_ready():
    id = client.get_guild(GUILD)
    y = open(r'..\scraped\members.txt', 'a')
    for member in id.members:
        y.write(f"{member.id}\n")
    i = open(r'..\scraped\channels.txt','a')
    for channel in id.channels:
        i.write(f"{channel.id}\n")
    y6 = open(r'..\scraped\roles.txt', 'a')
    for role in id.roles:
        y6.write(f"{role.id}\n")
    em = open (r'..\scraped\emojis.txt', 'a')
    for emoji in id.emojis:
        em.write(f"{emoji.id}\n")
    sys.exit()


client.run(TOKEN)

#  $$$$$$\             $$\            $$$$$$\                                                          $$$$$$$\             $$\               
# $$  __$$\            $$ |          $$  __$$\                                                         $$  __$$\            $$ |              
# $$ /  \__| $$$$$$\ $$$$$$\         $$ /  \__| $$$$$$\   $$$$$$\ $$\    $$\  $$$$$$\   $$$$$$\        $$ |  $$ | $$$$$$\ $$$$$$\    $$$$$$\  
# $$ |$$$$\ $$  __$$\\_$$  _|        \$$$$$$\  $$  __$$\ $$  __$$\\$$\  $$  |$$  __$$\ $$  __$$\       $$ |  $$ | \____$$\\_$$  _|   \____$$\ 
# $$ |\_$$ |$$$$$$$$ | $$ |           \____$$\ $$$$$$$$ |$$ |  \__|\$$\$$  / $$$$$$$$ |$$ |  \__|      $$ |  $$ | $$$$$$$ | $$ |     $$$$$$$ |
# $$ |  $$ |$$   ____| $$ |$$\       $$\   $$ |$$   ____|$$ |       \$$$  /  $$   ____|$$ |            $$ |  $$ |$$  __$$ | $$ |$$\ $$  __$$ |
# \$$$$$$  |\$$$$$$$\  \$$$$  |      \$$$$$$  |\$$$$$$$\ $$ |        \$  /   \$$$$$$$\ $$ |            $$$$$$$  |\$$$$$$$ | \$$$$  |\$$$$$$$ |
#  \______/  \_______|  \____/        \______/  \_______|\__|         \_/     \_______|\__|            \_______/  \_______|  \____/  \_______|
                                                                                                                                            
                                                                                                                                            
                                                                                                                                            
