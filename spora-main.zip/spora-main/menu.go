package main

import (
	"fmt"
	"spora/raid"
	"spora/servnuke"

	"github.com/manifoldco/promptui"
)

func menu() {
	prompt := promptui.Select{
		Label: "Select category",
		Items: []string{"Server Nuking", "Raid Servers", "Account Nuking", "Builders"},
	}

	_, result, err := prompt.Run()

	if err != nil {
		fmt.Printf("There was an error %v\n", err)
		return
	}

	switch result {
	case "Server Nuking":
		servnuke.Options()
	case "Raid Servers":
		raid.Options()
	default:
		fmt.Println("Category doesn't exist yet.")
		menu()
	}
}
